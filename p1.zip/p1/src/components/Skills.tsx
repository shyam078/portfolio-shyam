import React from "react";
import { motion } from "framer-motion";
import { Code2, Database, Layout, Server } from "lucide-react";
import {
  FaReact,
  FaNodeJs,
  FaJava,
  FaDatabase,
  FaDocker,
  FaAws,
  FaServer,
} from "react-icons/fa";
import {
  SiTypescript,
  SiGraphql,
  SiMysql,
  SiMongodb,
  SiPostgresql,
  SiRedis,
  SiFirebase,
  SiGoland,
  SiSpringboot,
  SiTailwindcss,
  SiRedux,
  SiGit,
  SiCypress,
  SiPostman,
  SiKubernetes,
} from "react-icons/si";

const skillCategories = [
  {
    title: "Frontend Development",
    icon: <FaReact className="w-8 h-8 mb-4 text-blue-400" />,
    skills: [
      { name: "React", icon: <FaReact className="text-blue-400" /> },
      { name: "TypeScript", icon: <SiTypescript className="text-blue-600" /> },
      { name: "JavaScript", icon: <SiGoland className="text-yellow-500" /> },
      {
        name: "Tailwind CSS",
        icon: <SiTailwindcss className="text-blue-400" />,
      },
      { name: "Redux", icon: <SiRedux className="text-purple-500" /> },
    ],
  },
  {
    title: "Backend Development",
    icon: <FaServer className="w-8 h-8 mb-4 text-green-400" />,
    skills: [
      { name: "Golang", icon: <SiGoland className="text-teal-500" /> },
      { name: "Java", icon: <FaJava className="text-red-500" /> },
      { name: "SpringBoot", icon: <SiSpringboot className="text-green-600" /> },
      { name: "Node.js", icon: <FaNodeJs className="text-green-400" /> },
      { name: "GraphQL", icon: <SiGraphql className="text-pink-400" /> },
      { name: "REST API", icon: <SiPostman className="text-orange-500" /> },
    ],
  },
  {
    title: "Database",
    icon: <FaDatabase className="w-8 h-8 mb-4 text-purple-400" />,
    skills: [
      { name: "MySQL", icon: <SiMysql className="text-blue-400" /> },
      { name: "MongoDB", icon: <SiMongodb className="text-green-400" /> },
      { name: "PostgreSQL", icon: <SiPostgresql className="text-blue-500" /> },
      { name: "Redis", icon: <SiRedis className="text-red-400" /> },
      { name: "Firebase", icon: <SiFirebase className="text-yellow-500" /> },
    ],
  },
  {
    title: "Other Skills",
    icon: <FaDocker className="w-8 h-8 mb-4 text-yellow-400" />,
    skills: [
      { name: "Git", icon: <SiGit className="text-orange-500" /> },
      { name: "Docker", icon: <FaDocker className="text-blue-600" /> },
      { name: "AWS", icon: <FaAws className="text-blue-700" /> },
      { name: "CI/CD", icon: <SiCypress className="text-green-500" /> },
      { name: "Kubernetes", icon: <SiKubernetes className="text-green-500" /> },
    ],
  },
];

const Skills = () => {
  return (
    <section className="bg-gray-800 text-white py-20 px-8" id="skills">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold text-center mb-12"
        >
          Skills & Expertise
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="bg-gray-700 p-6 rounded-lg text-center"
            >
              {category.icon}
              <h3 className="text-xl font-semibold mb-4">{category.title}</h3>
              <ul className="space-y-2">
                {category.skills.map((skill) => (
                  <li
                    key={skill.name}
                    className="flex items-center justify-center space-x-2"
                  >
                    {skill.icon}
                    <span>{skill.name}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
