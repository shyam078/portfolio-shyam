import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { Github, ExternalLink } from "lucide-react";

const projects = [
  {
    title: "Financial Risk Manager",
    description:
      "A financial risk management tool for banks to identify fraud transactions.",
    image: "/public/images/Fraud Risk Manager Illustration.webp",
    tags: [
      "Golang",
      "GorillaMux",
      "gRPC",
      "Protocol Buffers",
      "MySQL",
      "Docker",
      "Kubernetes",
      "Redis",
    ],
  },
  {
    title: "AI Driven Automation Deployment",
    description:
      "To automate the deployment process of AI models in the cloud.",
    image: "/public/images/AI Automation Illustration Dec 24.webp",
    tags: [
      "Golang",
      "Temporal",
      "gRPC",
      "Protocol Buffers",
      "AWS",
      "GCP",
      "Azure",
      "Cassandra",
    ],
  },
  {
    title: "Hospital Management System",
    description:
      "To manage the hospital operations efficiently. Also to maintain the patient records. And Book appointments.",
    image: "/public/images/AI Hospital Management System Illustration.webp",
    tags: ["java", "Spring Boot", "MySQL", "Docker", "Kubernetes", "React"],
  },
  {
    title: "ASI Web Application",
    description:
      "To manage Consultants, Clients, Projects, and Invoices. Also to generate reports.",
    image: "/public/images/Business Management System Illustration.webp",
    tags: ["React", "Redux", "Node.js", "Express", "MongoDB", "Docker"],
  },
];

const ProjectCard = ({
  project,
  index,
}: {
  project: (typeof projects)[0];
  index: number;
}) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.8, delay: index * 0.2 }}
      className={`bg-gray-800 rounded-lg overflow-hidden shadow-lg cursor-pointer transition-transform transform duration-300 hover:scale-105 group`}
    >
      <img
        src={project.image}
        alt={project.title}
        className="w-full h-auto object-contain"
      />

      <div className="p-6 group-hover:blur-none">
        <h3 className="text-xl font-bold mb-2">{project.title}</h3>
        <p className="text-gray-400 mb-4">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="bg-blue-500 text-sm px-3 py-1 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
        <div className="flex space-x-4">
          {/* <a
            href={project.github}
            className="text-gray-400 hover:text-white transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Github size={20} />
          </a>
          <a
            href={project.live}
            className="text-gray-400 hover:text-white transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <ExternalLink size={20} />
          </a> */}
        </div>
      </div>
    </motion.div>
  );
};

const Projects = () => {
  const [selectedProject, setSelectedProject] = useState<
    (typeof projects)[0] | null
  >(null);
  const descriptionRef = useRef<HTMLDivElement>(null);

  const handleProjectClick = (project: (typeof projects)[0]) => {
    setSelectedProject(project);

    // Scroll to the description section
    if (descriptionRef.current) {
      descriptionRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="bg-gray-900 text-white py-20 px-8" id="projects">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold text-center mb-12"
        >
          Featured Projects
        </motion.h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.title} project={project} index={index} />
          ))}
        </div>
        {selectedProject && (
          <div
            ref={descriptionRef}
            className="mt-12 p-6 bg-gray-800 rounded-lg shadow-lg"
          >
            <motion.h3
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-2xl font-bold mb-4"
            >
              {selectedProject.title}
            </motion.h3>
            <p className="text-gray-400 mb-4">{selectedProject.description}</p>
            <img
              src={selectedProject.image}
              alt={selectedProject.title}
              className="w-full h-48 object-cover rounded mb-4"
            />
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedProject.tags.map((tag) => (
                <span
                  key={tag}
                  className="bg-blue-500 text-sm px-3 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
            <div className="flex space-x-4">
              {/* <a
                href={selectedProject.github}
                className="text-gray-400 hover:text-white transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github size={20} />
              </a>
              <a
                href={selectedProject.live}
                className="text-gray-400 hover:text-white transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <ExternalLink size={20} />
              </a> */}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Projects;
