import React from 'react';
import { Code2, Database, Cloud as CloudIcon, Server } from 'lucide-react';

const skillCategories = [
  {
    title: 'Languages & Frameworks',
    icon: Code2,
    skills: ['Golang', 'Java', 'Spring Boot', 'React.js', 'Node.js', 'TypeScript'],
  },
  {
    title: 'Databases & API',
    icon: Database,
    skills: ['MySQL', 'PostgreSQL', 'MongoDB', 'REST API', 'gRPC', 'GraphQL'],
  },
  {
    title: 'Cloud Platforms',
    icon: CloudIcon,
    skills: ['AWS', 'Google Cloud', 'Azure', 'Kubernetes', 'Docker'],
  },
  {
    title: 'Tools & Others',
    icon: Server,
    skills: ['Git', 'CI/CD', 'Temporal', 'Microservices', 'System Design'],
  },
];

const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-12">Technical Skills</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="p-6 bg-gray-50 rounded-xl">
              <category.icon className="text-blue-600 mb-4" size={32} />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">{category.title}</h3>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, skillIndex) => (
                  <span
                    key={skillIndex}
                    className="px-3 py-1 bg-white border border-gray-200 rounded-full text-sm text-gray-700"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;