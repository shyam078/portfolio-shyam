import React from 'react';
import { Shield, Cloud, Activity } from 'lucide-react';

const projects = [
  {
    title: 'Fraud Risk Management System',
    icon: Shield,
    description: 'Built a comprehensive FRM system for ACS and Razorpay focusing on fraud detection and case management. Implemented secure transaction processing and real-time monitoring.',
    tech: ['Golang', 'gRPC', 'MySQL', 'Kubernetes', 'Docker'],
  },
  {
    title: 'Cloud Infrastructure Automation',
    icon: Cloud,
    description: 'Developed an AI-driven deployment platform for managing cloud infrastructure across multiple providers. Implemented workflow automation using Temporal.',
    tech: ['Golang', 'AWS', 'GCP', 'Azure', 'Temporal'],
  },
  {
    title: 'Healthcare Management System',
    icon: Activity,
    description: 'Created a scalable healthcare platform with microservices architecture for managing doctor-patient relationships and medical records.',
    tech: ['Java', 'Spring Boot', 'MySQL', 'React.js', 'Docker'],
  },
];

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-12">Featured Projects</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <project.icon className="text-blue-600 mb-4" size={32} />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{project.title}</h3>
              <p className="text-gray-600 mb-4">{project.description}</p>
              <div className="flex flex-wrap gap-2">
                {project.tech.map((tech, techIndex) => (
                  <span
                    key={techIndex}
                    className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;