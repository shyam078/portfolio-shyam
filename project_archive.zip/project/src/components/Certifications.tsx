import React from 'react';
import { Award } from 'lucide-react';

const certifications = [
  {
    title: 'Full Stack Java Development',
    issuer: 'Professional Certification',
    date: '2023',
  },
  {
    title: 'Generative AI Applications on AWS',
    issuer: 'AWS Certification',
    date: '2024',
  },
];

const Certifications = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-12">Certifications</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {certifications.map((cert, index) => (
            <div key={index} className="flex items-start space-x-4 bg-white p-6 rounded-xl shadow-sm">
              <Award className="text-blue-600 flex-shrink-0" size={24} />
              <div>
                <h3 className="text-xl font-semibold text-gray-900">{cert.title}</h3>
                <p className="text-gray-600">{cert.issuer}</p>
                <p className="text-sm text-gray-500">{cert.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;