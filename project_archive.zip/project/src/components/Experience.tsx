import React from 'react';
import { Building2, Calendar } from 'lucide-react';

const experiences = [
  {
    company: 'Collabera Digital',
    position: 'Software Engineer',
    period: 'September 2024 - Present',
    description: 'Working on AI-driven deployment platform for cloud infrastructure automation using AWS, GCP, and Azure. Implementing complex workflows with Temporal and Golang.',
  },
  {
    company: 'BRR Software Systems',
    position: 'Software Engineer',
    period: 'April 2022 - September 2024',
    description: 'Developed Fraud Risk Management (FRM) system for ACS and Razorpay. Built scalable microservices using Golang and gRPC. Implemented containerized solutions with Kubernetes and Docker.',
  },
];

const Experience = () => {
  return (
    <section id="experience" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-12">Professional Experience</h2>
        <div className="space-y-12">
          {experiences.map((exp, index) => (
            <div key={index} className="border-l-4 border-blue-600 pl-6">
              <div className="flex items-center mb-2">
                <Building2 className="text-blue-600 mr-2" size={20} />
                <h3 className="text-xl font-semibold text-gray-900">{exp.company}</h3>
              </div>
              <div className="flex items-center text-gray-600 mb-3">
                <Calendar className="mr-2" size={16} />
                <span>{exp.period}</span>
              </div>
              <h4 className="text-lg font-medium text-gray-800 mb-2">{exp.position}</h4>
              <p className="text-gray-600">{exp.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;